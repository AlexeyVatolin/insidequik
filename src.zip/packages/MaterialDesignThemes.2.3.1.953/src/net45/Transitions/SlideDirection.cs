﻿namespace MaterialDesignThemes.Wpf.Transitions
{
    public enum SlideDirection { Left, Right, Up, Down }
}